#include "Bullet.hpp"    

    Bullet::Bullet(SDL_Renderer* rend, SDL_Texture* ast, SDL_Rect mov): Unit(rend, ast), mover(mov){
        src = {616, 201, 302, 96};
    }

    void Bullet::draw(){

    if (mover.x >= 975)
    {
        // mover.x = 1000 - mover.w;
        if (src.x == 616)
        {
            src = {39, 394, 92, 95};
            Unit::draw(src, mover);
        }
        else if (src.x == 39)
        {
            src = {189, 373, 133, 141};
            Unit::draw(src, mover);
        }
        else if (src.x == 189)
        {
            src = {339, 362, 162, 165};
            Unit::draw(src, mover);
        }
        else if (src.x == 339)
        {
            src = {506, 362, 162, 165};
            Unit::draw(src, mover);
        }
        else if (src.x == 506)
        {
            src = {681, 362, 154, 165};
            Unit::draw(src, mover);
        }
        else if (src.x == 681)
        {
            src = {847, 362, 154, 165};
            Unit::draw(src, mover);
        }
        else if (src.x == 847)
        {
            src = {1010, 362, 158, 165};
            Unit::draw(src, mover);
            // mover.x += 200;
            src = {0, 0, 0, 0};
        }
    }
    else
    {
        mover.x += 20;
        Unit::draw(src, mover);
    }
    }