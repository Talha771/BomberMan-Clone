#include "Unit.hpp"
#include <iostream>
using namespace std;


class block: public Unit{
    SDL_Rect src,mover;
    public:
    block(SDL_Renderer* rend, SDL_Texture* ast, SDL_Rect mov);
    void draw();
};