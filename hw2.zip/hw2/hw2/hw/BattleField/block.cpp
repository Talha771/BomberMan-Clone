#include "block.hpp"    

    block::block(SDL_Renderer* rend, SDL_Texture* ast, SDL_Rect mov): Unit(rend, ast), mover(mov){
        src = {0, 0, 16, 16};
    }
    void block::draw(){
    Unit::draw(src,mover);
    // cout<<"Lmao";
    }

