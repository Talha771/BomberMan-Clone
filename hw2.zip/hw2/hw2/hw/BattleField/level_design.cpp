#include "level_design.hpp"

void level_design::drawObjects(){
    SDL_Rect mov1={120,130,170,160};
    // call draw functions of all the objects here
    for(block& b: block1)
    b.draw();
}

void level_design::createObject(int x, int y){
    std::cout<<"Mouse clicked at: "<<x<<" -- "<<y<<std::endl;
    generate_boundary_wall();

}
void level_design::generate_boundary_wall(){
       generate_sdl_grid();
    for (int i=0;i<12;i++){
    block b1 (gRenderer,assets,grid[i][0]);
    block1.push_back(b1);
    }
    for (int i=0;i<10;i++){
        block b1 (gRenderer,assets,grid[0][i]);
        block1.push_back(b1);
    }
    for (int i=0;i<12;i++){
        block b1 (gRenderer,assets,grid[i][9]);
        block1.push_back(b1);
    }
    for (int i=0;i<10;i++){
    block b1(gRenderer,assets,grid[11][i]);
    block1.push_back(b1);
    }
}

level_design::level_design(SDL_Renderer *renderer, SDL_Texture *asst):gRenderer(renderer), assets(asst){
}

// Bullet level_design::fire(){
//     cout<<"F key is pressed"<<endl;
//     // for (tank&turret : t2){
//     //     Bullet b1=turret.fire(gRenderer,assets,turret.t.mover);
//     //     bullets.push_back(b1);
// }
// }
