#include<SDL.h>
#include "Bullet.hpp"
#include "game.hpp"
#include<iostream>
#include "block.hpp"
// #include "Tank-turret.hpp"
// #include "Tank.hpp"
#include<list>
using namespace std;
class level_design:public Game{
    public:
    list<Bullet> bullets;
    list <block> block1;
    SDL_Renderer *gRenderer;
    SDL_Texture *assets;
    level_design(SDL_Renderer *, SDL_Texture *);
    void drawObjects(); 
    void createObject(int, int);
    void generate_boundary_wall();
};